git fetch
git status
git push